"""Test polyglot.

----------------------------------

Tests for `polyglot` module.
"""
# import unittest
# from polyglot import polyglot
from polyglot.detect import Detector

_ = """
class TestPolyglot(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()
# """

def test_sanity():
    """Sanity test."""
    arabic_text = u"""
    أفاد مصدر امني في قيادة عمليات صلاح الدين في العراق بأن " القوات الامنية تتوقف لليوم
    الثالث على التوالي عن التقدم الى داخل مدينة تكريت بسبب
    انتشار قناصي التنظيم الذي يطلق على نفسه اسم "الدولة الاسلامية" والعبوات الناسفة
    والمنازل المفخخة والانتحاريين، فضلا عن ان القوات الامنية تنتظر وصول تعزيزات اضافية ".
    """
    detector = Detector(arabic_text)
    print(detector.language)
    # name: Arabic      code: ar       confidence:  99.0 read bytes:   907
    assert detector.language.name.lower() == "arabic"
    assert detector.language.code == "ar"
    assert detector.language.confidence > 98
    