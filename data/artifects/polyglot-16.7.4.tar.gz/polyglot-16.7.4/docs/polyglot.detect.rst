polyglot.detect package
=======================

Submodules
----------

polyglot.detect.base module
---------------------------

.. automodule:: polyglot.detect.base
    :members:
    :undoc-members:
    :show-inheritance:

polyglot.detect.langids module
------------------------------

.. automodule:: polyglot.detect.langids
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: polyglot.detect
    :members:
    :undoc-members:
    :show-inheritance:
