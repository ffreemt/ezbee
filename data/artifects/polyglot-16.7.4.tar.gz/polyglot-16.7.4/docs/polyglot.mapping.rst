polyglot.mapping package
========================

Subpackages
-----------

.. toctree::

    polyglot.mapping.tests

Submodules
----------

polyglot.mapping.base module
----------------------------

.. automodule:: polyglot.mapping.base
    :members:
    :undoc-members:
    :show-inheritance:

polyglot.mapping.embeddings module
----------------------------------

.. automodule:: polyglot.mapping.embeddings
    :members:
    :undoc-members:
    :show-inheritance:

polyglot.mapping.expansion module
---------------------------------

.. automodule:: polyglot.mapping.expansion
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: polyglot.mapping
    :members:
    :undoc-members:
    :show-inheritance:
