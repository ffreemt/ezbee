polyglot.tag package
====================

Subpackages
-----------

.. toctree::

    polyglot.tag.tests

Submodules
----------

polyglot.tag.base module
------------------------

.. automodule:: polyglot.tag.base
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: polyglot.tag
    :members:
    :undoc-members:
    :show-inheritance:
